<?php
if ($_GET['randomId'] != "u9EnYfD_Ma1hYwyPDLax30rt6mzVMiqjlvWbqTPtG0H0Kboy4Z6dbkoQRRcz4yti") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
